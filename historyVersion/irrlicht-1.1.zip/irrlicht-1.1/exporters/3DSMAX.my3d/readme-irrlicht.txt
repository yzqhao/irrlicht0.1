This directory contains the exporters for MAX5, MAX6 and MAX7 for the my3d file format by 
Zhuck Dimitry. These are parts of the my3dtools package which can be obtained from 
http://my3dproject.nm.ru
The source.zip includes the full source of the included exporters and further documentation
of the format etc. For more information read the file readme.txt in the parent directory 
or the original readme file of this package:


All started here 
http://irrlicht.sourceforge.net/phpBB2/viewtopic.php?t=3198&postdays=0&postorder=asc&start=150

My3D Tools package created by ZDimitor, tools allowing to export 
lightmapped scenes from 3DMAX and Gile[s] directly into Irrlicht. 


Tools list:
 
My3D Tools v.1  
 - Irrlicht loader
 - 3DSMAX5 exporter

My3D Tools v.2
 - Irrlicht loader
 - 3DSMAX5 exporter
 - MAX5 example

My3D Tools v.3
 - Irrlicht loader
 - 3DSMAX5 exporter
 - MAX5 example

My3D Tools v.3.1 - Mar 13, 2005
 - Irrlicht loader
 - 3DSMAX5 exporter
 - 3DSMAX6 exporter
 - 3DSMAX7 exporter
 - Gile[s] 1.3 exporter
 - MAX5, MAX6, MAX 7 and Giles[s] 1.3 example


Comments about this project, please e-mail me at: zdimitor@pochta.ru

Thanks for downloading!...
