These Tutorials have simply been copied from the Irrlicht Wiki at http://www.irrforge.org
They are written by different authors, and not guaranteed to work, they simply should provide 
the c++ examples ported the Irrlicht.NET.
Please see the wiki for updates and more info.
A lot of thanks go to the people who wrote these examples.