Sorry, I cannot provide a procompiled lib for Win64.
Please goto the \source directory, unzip the source.zip file 
and compile them yourself, it will cost you about 3 minutes. :)