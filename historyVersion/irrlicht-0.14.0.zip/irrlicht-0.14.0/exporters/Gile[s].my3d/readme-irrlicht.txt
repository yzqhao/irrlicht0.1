This directory contains the exporter for Gile[s] 1.3 for the my3d file format by 
Zhuck Dimitry. This is a part of the my3dtools package which can be obtained from 
http://my3dproject.nm.ru
For the source and further information and documentation, please take a look into
the source.zip file which is included in the exporters\3DSMAX.my3d\ directory.
Other more basic informations can be found in readme.txt in the parent directory.