========================================================================
    DYNAMIC LINK LIBRARY : Irrlicht.NET Project Overview
========================================================================

AppWizard has created this Irrlicht.NET DLL for you.  

This file contains a summary of what you will find in each of the files that
make up your Irrlicht.NET application.

Irrlicht.NET.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

Irrlicht.NET.cpp
    This is the main DLL source file.

Irrlicht.NET.h
    This file contains a class declaration.

AssemblyInfo.cpp
	Contains custom attributes for modifying assembly metadata.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
